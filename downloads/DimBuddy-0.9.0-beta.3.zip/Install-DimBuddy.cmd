@echo off
setlocal EnableExtensions

set "APPNAME=Dim Buddy"
set "SOURCE=%~dp0Payload"
set "DEST=%ProgramData%\DimBuddy"
set "STAGE=%ProgramData%\DimBuddy.installing"
set "BACKUP=%ProgramData%\DimBuddy.backup"
set "DLL=%DEST%\DimBuddy.Addin.dll"
set "REGASM=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\RegAsm.exe"
set "LOG=%~dp0DimBuddy-Install.log"

echo Dim Buddy test deployment > "%LOG%"
echo Started: %DATE% %TIME% >> "%LOG%"

net session >nul 2>&1
if errorlevel 1 (
  echo.
  echo This installer must be run as administrator.
  echo Right-click Install-DimBuddy.cmd and choose Run as administrator.
  echo ERROR: Administrator rights are required. >> "%LOG%"
  pause
  exit /b 1
)

tasklist /FI "IMAGENAME eq SLDWORKS.exe" 2>nul | find /I "SLDWORKS.exe" >nul
if not errorlevel 1 (
  echo.
  echo Close SOLIDWORKS before installing Dim Buddy.
  echo ERROR: SOLIDWORKS was running. >> "%LOG%"
  pause
  exit /b 2
)

if not exist "%SOURCE%\DimBuddy.Addin.dll" (
  echo.
  echo The deployment payload is missing.
  echo Expected: "%SOURCE%\DimBuddy.Addin.dll"
  echo ERROR: Payload missing. >> "%LOG%"
  pause
  exit /b 3
)

if not exist "%REGASM%" (
  echo.
  echo Microsoft .NET Framework 4.8 registration tools were not found.
  echo Expected: "%REGASM%"
  echo ERROR: RegAsm missing. >> "%LOG%"
  pause
  exit /b 4
)

if exist "%STAGE%" rmdir /S /Q "%STAGE%" >> "%LOG%" 2>&1
if exist "%BACKUP%" rmdir /S /Q "%BACKUP%" >> "%LOG%" 2>&1

echo Preparing the new Dim Buddy version...
mkdir "%STAGE%" >> "%LOG%" 2>&1
xcopy "%SOURCE%\*" "%STAGE%\" /E /I /Y /Q >> "%LOG%" 2>&1
if errorlevel 1 (
  echo.
  echo Dim Buddy files could not be copied. Company security may have blocked the operation.
  echo See: "%LOG%"
  pause
  exit /b 5
)

if not exist "%STAGE%\DimBuddy.Addin.dll" (
  echo.
  echo The staged Dim Buddy files could not be verified.
  echo See: "%LOG%"
  pause
  exit /b 5
)

if exist "%DLL%" (
  echo Removing the previous Dim Buddy registration...
  "%REGASM%" "%DLL%" /unregister >> "%LOG%" 2>&1
)

if exist "%DEST%" move "%DEST%" "%BACKUP%" >> "%LOG%" 2>&1
move "%STAGE%" "%DEST%" >> "%LOG%" 2>&1
if errorlevel 1 goto :rollback

echo Registering Dim Buddy...
"%REGASM%" "%DLL%" /codebase >> "%LOG%" 2>&1
if errorlevel 1 (
  goto :rollback
)

reg query "HKLM\SOFTWARE\SOLIDWORKS\Addins\{A4261F35-232C-4DB6-A015-D84E024BCB8B}" >nul 2>&1
if errorlevel 1 (
  goto :rollback
)

if exist "%BACKUP%" rmdir /S /Q "%BACKUP%" >> "%LOG%" 2>&1
echo SUCCESS >> "%LOG%"
echo.
echo Dim Buddy was installed successfully.
echo Start SOLIDWORKS, then check Tools ^> Add-Ins for Dim Buddy.
pause
exit /b 0

:rollback
echo ERROR: The upgrade failed; attempting to restore the previous version. >> "%LOG%"
if exist "%DLL%" "%REGASM%" "%DLL%" /unregister >> "%LOG%" 2>&1
if exist "%DEST%" rmdir /S /Q "%DEST%" >> "%LOG%" 2>&1
if exist "%BACKUP%" move "%BACKUP%" "%DEST%" >> "%LOG%" 2>&1
if exist "%DLL%" "%REGASM%" "%DLL%" /codebase >> "%LOG%" 2>&1
echo.
echo The Dim Buddy upgrade failed. The previous version was restored when possible.
echo See: "%LOG%"
pause
exit /b 6
