@echo off
setlocal EnableExtensions

set "DEST=%ProgramData%\DimBuddy"
set "DLL=%DEST%\DimBuddy.Addin.dll"
set "REGASM=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\RegAsm.exe"
set "LOG=%~dp0DimBuddy-Uninstall.log"

echo Dim Buddy removal > "%LOG%"
echo Started: %DATE% %TIME% >> "%LOG%"

net session >nul 2>&1
if errorlevel 1 (
  echo.
  echo This uninstaller must be run as administrator.
  echo Right-click Uninstall-DimBuddy.cmd and choose Run as administrator.
  pause
  exit /b 1
)

tasklist /FI "IMAGENAME eq SLDWORKS.exe" 2>nul | find /I "SLDWORKS.exe" >nul
if not errorlevel 1 (
  echo.
  echo Close SOLIDWORKS before removing Dim Buddy.
  pause
  exit /b 2
)

if exist "%DLL%" (
  "%REGASM%" "%DLL%" /unregister >> "%LOG%" 2>&1
)

reg delete "HKLM\SOFTWARE\SOLIDWORKS\Addins\{A4261F35-232C-4DB6-A015-D84E024BCB8B}" /f >> "%LOG%" 2>&1
reg delete "HKCU\Software\SOLIDWORKS\AddInsStartup\{A4261F35-232C-4DB6-A015-D84E024BCB8B}" /f >> "%LOG%" 2>&1

if exist "%DEST%" rmdir /S /Q "%DEST%" >> "%LOG%" 2>&1

echo.
echo Dim Buddy was removed.
pause
exit /b 0
