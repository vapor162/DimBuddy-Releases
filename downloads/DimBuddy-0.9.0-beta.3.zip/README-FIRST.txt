DIM BUDDY - VERSIONED TEST RELEASE
==================================

This release is compiled with the SOLIDWORKS 2026 interop assemblies. The
source only calls APIs available in SOLIDWORKS 2024, but each release must
still be tested on an actual SOLIDWORKS 2024 computer.

INSTALL
1. Copy the entire extracted folder to the target computer.
2. Close SOLIDWORKS.
3. Right-click Install-DimBuddy.cmd and choose Run as administrator.
4. Start SOLIDWORKS.
5. Open Tools > Add-Ins and confirm Dim Buddy is checked.

UPGRADE
Run Install-DimBuddy.cmd again while SOLIDWORKS is closed. The installer
stages the new files, keeps a temporary copy of the prior installation, and
restores the prior version if registration of the update fails.

PRESERVED DURING UPGRADES
- Macro assignments and custom macro icons
- Theme, density, favorites, and collapsed-section preferences
- SOLIDWORKS toolbar and CommandManager customization

These settings are stored outside C:\ProgramData\DimBuddy and are never
included in or overwritten by the release payload.

If Windows shows an Unblock checkbox in the ZIP file's Properties, unblock
the ZIP before extracting it. Do not disable company antivirus or security
controls. If installation is denied, provide DimBuddy-Install.log to IT.

UNINSTALL
1. Close SOLIDWORKS.
2. Right-click Uninstall-DimBuddy.cmd and choose Run as administrator.

Uninstalling also leaves personal settings in place for a future reinstall.

Installed location:
  C:\ProgramData\DimBuddy

Personal settings location:
  %APPDATA%\DimBuddy

Requirements:
- 64-bit Windows
- Microsoft .NET Framework 4.8
- SOLIDWORKS 2024 or later for this test
- Local administrator permission for COM and SOLIDWORKS add-in registration
